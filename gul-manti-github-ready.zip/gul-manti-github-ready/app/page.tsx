export default function Home(){
return (
<main style={{padding:40}}>
<h1>GÜL MANTI CAFE</h1>
<h2>Makine Değil, El Yapımı</h2>
<p>0542 463 08 45</p>
<a href='https://wa.me/905424630845'>WhatsApp Sipariş</a>
</main>
)}
